const botaoMostraPalavra = document.querySelector('#botao-palavra');

botaoMostraPalavra.addEventListener('click', mostraPalavrasChave);

function mostraPalavrasChave() {
    const texto = document.querySelector ('#entrada-de-texto').value;
    const campoResultado = document.querySelector ('resultado-palavrachave');
    const Palavrascave = processaTexto (texto);

    campoResultado.textContent = palavars.join (", ");
}
    
function processaTexto (texto){
    let palavars = texto.slipt(/[a-zA-z]+/);
    return palavars;
}