const botaoMostraPalavra = document.querySelector('#botao-palavra');

botaoMostraPalavra.addEventListener('click', mostraPalavrasChave);

function mostraPalavrasChave()