const botaoMostraPalavra = document.querySelector('#botao-palavra');

botaoMostraPalavra.addEventListener('click', mostraPalavrasChave);

function mostraPalavrasChave() {
    const texto = document.querySelector ('#entrada-de-texto').value;
    const campoResultado = document.querySelector ('resultado-palavrachave');
    const Palavrascave = processaTexto (texto);

    campoResultado.textContent = palavars.join (", ");
    campoResultado.textoContent = PalavrasChve.join(",");
}
    
function processaTexto (texto)
    let palavars = texto.slipt(/p{L}+/u);
    
    let frequencias = {};
    for (let i of palavras){
        frequencias [i] = 0;
        for (let j of palavras){
            if (i == j){
                frequencias [i]+;
                {
                
            }
                
            }
            const element = array[index];
            
        }
        const element = array[i of palavras];
        
    }
}